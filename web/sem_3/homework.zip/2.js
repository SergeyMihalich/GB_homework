function greeting() {
    let name = prompt('Введи имя: ');
    res = `Привет, ${name}!!`
};

greeting();
console.log(res);